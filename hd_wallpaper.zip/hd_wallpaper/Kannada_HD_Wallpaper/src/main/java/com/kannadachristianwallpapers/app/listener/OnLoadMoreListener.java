package com.kannadachristianwallpapers.app.listener;

public interface OnLoadMoreListener {
    void onLoadMore();
}