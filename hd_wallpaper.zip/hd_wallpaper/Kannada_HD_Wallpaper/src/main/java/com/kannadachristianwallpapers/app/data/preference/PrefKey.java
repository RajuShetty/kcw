package com.kannadachristianwallpapers.app.data.preference;


public class PrefKey {
    // preference keys
    public static final String APP_PREFERENCE = "app_prefs";
}
