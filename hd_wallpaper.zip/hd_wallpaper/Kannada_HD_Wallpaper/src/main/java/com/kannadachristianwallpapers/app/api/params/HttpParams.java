package com.kannadachristianwallpapers.app.api.params;


public class HttpParams {
    // replace by your site url
    public static final String BASE_URL = "http://kannadachristiansongs.in/Christianwallpapers/wp-json/";

    public static final String API_CATEGORIES = "wp/v2/categories";
    public static final String API_GIF_ID = "wp/v2/categories";
    public static final String API_WALLPAPERS = "wp/v2/posts";
    public static final String API_FEATURED = "wp/v2/posts";
    public static final String API_SEARCH = "wp/v2/posts";
    public static final String API_FEATURED_ID = "wp/v2/tags";
    public static final String API_INCREASE_VIEW = "post-counter-extender/posts";
}
